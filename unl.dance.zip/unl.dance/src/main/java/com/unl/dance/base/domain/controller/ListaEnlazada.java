package com.unl.dance.base.domain.controller;
import java.io.BufferedReader;
import java.io.FileReader;

public class ListaEnlazada {

    static class Node {
        Integer data;
        Node next;
        boolean counted;

        public Node(Integer data) {
            this.data = data;
            this.next = null;
            this.counted = false;
        }
    }

    static class LinkedList {
        Node head;

        public LinkedList() {
            this.head = null;
        }

        public void add(Integer data) {
            Node newNode = new Node(data);
            if (head == null) {
                head = newNode;
            } else {
                Node current = head;
                while (current.next != null) {
                    current = current.next;
                }
                current.next = newNode;
            }
        }

        public void printList() {
            Node current = head;
            while (current != null) {
                System.out.print(current.data);
                if (current.next != null) {
                    System.out.print(", ");
                }
                current = current.next;
            }
            System.out.println();
        }

        public int countRepeated() {
            int count = 0;
            Node current = head;
            while (current != null) {
                if (!current.counted) {
                    int occurrences = 0;
                    Node checkNode = head;
                    while (checkNode != null) {
                        if (checkNode.data.equals(current.data)) {
                            occurrences++;
                        }
                        checkNode = checkNode.next;
                    }
                    if (occurrences > 1) {
                        count++;
                        Node temp = head;
                        while (temp != null) {
                            if (temp.data.equals(current.data)) {
                                temp.counted = true;
                            }
                            temp = temp.next;
                        }
                    }
                }
                current = current.next;
            }
            return count;
        }
    }

    public static void main(String[] args) {
        ListaEnlazada app = new ListaEnlazada();
        app.DataProcess();
    }

    public void PrintResult(LinkedList list, String titulo) {
        System.out.println(titulo + ":");
        list.printList();
    }

    public Integer countLin() {
        Integer cantidad = 0;
        String dir = "/home/fabricio/Descargas/data.txt";
        try {
            BufferedReader br = new BufferedReader(new FileReader(dir));
            while (br.readLine() != null) {
                cantidad++;
            }
            br.close();
        } catch (Exception e) {
            System.out.println("Archivo no encontrado " + e.getMessage());
        }
        return cantidad;
    }

    public void DataProcess() {
        Long InitialTime = System.nanoTime();

        String dir = "/home/fabricio/Descargas/data.txt";
        Integer cantidadLineas = countLin();
        LinkedList lista = new LinkedList();

        try {
            BufferedReader br = new BufferedReader(new FileReader(dir));
            String linea;

            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    lista.add(Integer.parseInt(linea.trim()));
                }
            }
            br.close();
        } catch (Exception e) {
            System.out.println("Error al leer el archivo data: " + e.getMessage());
        }
        int numRepeated = lista.countRepeated();

        Long FinalTime = System.nanoTime();
        Long Duration = FinalTime - InitialTime;

        PrintResult(lista, "Elementos en la lista");
        System.out.println("Cantidad de elementos repetidos: " + numRepeated);
        System.out.println("Tiempo de ejecución: " + Duration + " ns");
    }
}
