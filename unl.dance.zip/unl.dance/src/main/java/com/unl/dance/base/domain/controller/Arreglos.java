package com.unl.dance.base.domain.controller;

import java.io.BufferedReader;
import java.io.FileReader;

public class Arreglos {
    public static void main(String[] args) {
        Arreglos app = new Arreglos();
        app.DataProcess();
    }

    public void PrintResult(Integer[] arreglo, String titulo) {
        System.out.println(titulo + ":");
        
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print(arreglo[i]);
            if (i < arreglo.length - 1) {
                System.out.print(", ");
            }
        }
    }

    public Integer countLin(){
        Integer cantidad = 0;
        String dir = "/home/fabricio/Descargas/data.txt";
        try {
            BufferedReader br = new BufferedReader(new FileReader(dir));
            while (br.readLine() != null) {
                cantidad++;
            }
            br.close();
        } catch (Exception e) {
            System.out.println("Archivo no encontrado " + e.getMessage());
        }
        return cantidad;
    }

    public void DataProcess() {
        Long InitialTime = System.nanoTime();

        String dir = "/home/fabricio/Descargas/data.txt";
        Integer cantidadLineas = countLin();
        Integer[] arreglo = new Integer[cantidadLineas];
        int i = 0;

        try {
            BufferedReader br = new BufferedReader(new FileReader(dir));
            String linea;

            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    arreglo[i] = Integer.parseInt(linea.trim());
                    i++;
                }
            }
            br.close();
        } catch (Exception e) {
            System.out.println("Error al leer el archivo data: " + e.getMessage());
        }

        // Crear un arreglo de conteo
        Integer[] contador = new Integer[cantidadLineas];
        for (int j = 0; j < cantidadLineas; j++) {
            contador[j] = 0;  // Inicializar el contador
        }

        for (int j = 0; j < arreglo.length; j++) {
            for (int k = j + 1; k < arreglo.length; k++) {
                if (arreglo[j] != null && arreglo[j].equals(arreglo[k])) {
                    contador[j]++;
                    arreglo[k] = null;  // Marcar el valor ya contado
                }
            }
        }

        // Contar los elementos repetidos
        int numRepeated = 0;
        for (int j = 0; j < contador.length; j++) {
            if (contador[j] > 0) {
                numRepeated++;
            }
        }

        // Crear el arreglo de los elementos repetidos
        Integer[] repetidos = new Integer[numRepeated];
        int index = 0;
        for (int j = 0; j < contador.length; j++) {
            if (contador[j] > 0) {
                repetidos[index++] = arreglo[j];
            }
        }

        Long FinalTime = System.nanoTime();
        Long Duration = FinalTime - InitialTime;

        PrintResult(repetidos, "Elementos repetidos");
        System.out.println("Cantidad de elementos repetidos: " + numRepeated);
        System.out.println("Tiempo de ejecución: " + Duration + " ns");
    }
}
