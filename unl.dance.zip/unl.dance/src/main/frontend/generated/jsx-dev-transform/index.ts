import { createElement as reactCreateElement } from "react";

export const createElement = reactCreateElement;
